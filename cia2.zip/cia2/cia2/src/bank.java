import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

class BankEmployee {
    int employeeId;
    String name;
    int age;
    String designation;
    String department;

    BankEmployee(int employeeId, String name, int age, String designation, String department) {
        this.employeeId = employeeId;
        this.name = name;
        this.age = age;
        this.designation = designation;
        this.department = department;
    }
}

class BankManagement {
    private Connection connection;
    private Statement statement;
    private JTextArea outputArea;

    BankManagement(JTextArea outputArea) {
        this.outputArea = outputArea;
        initializeDatabase();
    }

    private void initializeDatabase() {
        String jdbcUrl = "jdbc:mysql://localhost:3306/bank";
        String user = "root";
        String password = "aditipatel@0811";

        try {
            connection = DriverManager.getConnection(jdbcUrl, user, password);
            statement = connection.createStatement();

            // Create Bank table
            String createBankTable = "CREATE TABLE IF NOT EXISTS Bank (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "employeeId INT," +
                    "name VARCHAR(255) NOT NULL," +
                    "age INT NOT NULL," +
                    "designation VARCHAR(255) NOT NULL," +
                    "department VARCHAR(255) NOT NULL)";
            statement.executeUpdate(createBankTable);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void registerEmployee(int employeeId, String name, int age, String designation, String department) {
        BankEmployee newEmployee = new BankEmployee(employeeId, name, age, designation, department);

        try {
            String insertQuery = String.format("INSERT INTO Bank (employeeId, name, age, designation, department) VALUES (%d, '%s', %d, '%s', '%s')",
                    newEmployee.employeeId, newEmployee.name, newEmployee.age, newEmployee.designation, newEmployee.department);
            statement.executeUpdate(insertQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void searchEmployee(String searchCriteria) {
        try {
            String query = "SELECT * FROM Bank WHERE name LIKE '%" + searchCriteria + "%' OR department LIKE '%" + searchCriteria + "%'";
            ResultSet resultSet = statement.executeQuery(query);

            // Clear previous output
            outputArea.setText("");

            // Display search results
            while (resultSet.next()) {
                String result = "Employee ID: " + resultSet.getInt("employeeId") + "\n" +
                                "Name: " + resultSet.getString("name") + "\n" +
                                "Age: " + resultSet.getInt("age") + "\n" +
                                "Designation: " + resultSet.getString("designation") + "\n" +
                                "Department/Section: " + resultSet.getString("department") + "\n" +
                                "==============================================================\n\n\n";
                updateOutput(result);
            }

            // Close resources
            resultSet.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void closeDatabase() {
        try {
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void updateOutput(String message) {
        outputArea.append(message);
    }
}

public class bank extends JFrame {
    private BankManagement bankManagement;
    private JTextField employeeIdField, nameField, ageField, designationField, departmentField;
    private JTextArea outputArea;

    public bank() {
        outputArea = new JTextArea(20, 50);
        outputArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(outputArea);
        JButton registerEmployeeButton = new JButton("Register Employee");
        JButton searchEmployeeButton = new JButton("Search Employee");
        JButton exitButton = new JButton("Exit");

        employeeIdField = new JTextField(10);
        nameField = new JTextField(20);
        ageField = new JTextField(5);
        designationField = new JTextField(20);
        departmentField = new JTextField(20);

        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(6, 2));

        formPanel.add(new JLabel("Bank Employee ID:"));
        formPanel.add(employeeIdField);
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Age:"));
        formPanel.add(ageField);
        formPanel.add(new JLabel("Designation:"));
        formPanel.add(designationField);
        formPanel.add(new JLabel("Department/Section:"));
        formPanel.add(departmentField);
        formPanel.add(registerEmployeeButton);
        formPanel.add(searchEmployeeButton);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        buttonPanel.add(exitButton);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        // Create BankManagement with the initialized outputArea
        bankManagement = new BankManagement(outputArea);

        registerEmployeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerEmployee();
            }
        });

        searchEmployeeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchEmployee();
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                bankManagement.closeDatabase();
                System.exit(0);
            }
        });

        setTitle("Bank Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null); // Center the frame
        setVisible(true);
    }

    private void registerEmployee() {
        int employeeId = Integer.parseInt(employeeIdField.getText());
        String name = nameField.getText();
        int age = Integer.parseInt(ageField.getText());
        String designation = designationField.getText();
        String department = departmentField.getText();

        bankManagement.registerEmployee(employeeId, name, age, designation, department);
        updateOutput("Employee registered: Bank Employee ID " + employeeId);
    }

    private void searchEmployee() {
        String searchCriteria = JOptionPane.showInputDialog("Enter search criteria (Name or Department):");
        bankManagement.searchEmployee(searchCriteria);
    }

    private void updateOutput(String message) {
        outputArea.append(message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new bank();
            }
        });
    }
}
